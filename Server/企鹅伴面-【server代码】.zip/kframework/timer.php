<?php 
/**
 * 定时器，计算某一段代码的执行时间。
 * 时间单位是毫秒
 * @author laiwenhui
 *
 */
class timer
{
	/**
	 * 用于存在时间数据：开始时间和结束时间
	 * @var array
	 * {
	 * 		start : 开始时间
	 * 		end : 结束时间
	 * }
	 */
	protected static $_arrData = array();
	/**
	 * 执行的时间，us。
	 * @var array
	 * {
	 * 		$strName => $intTimeUs
	 * }
	 */
	protected static $_arrExecutionTime = array();
	
	/**
	 * 计时开始。
	 * @param string $strName
	 */
	public static function start($strName)
	{
		self::$_arrData[$strName]['end'] = self::$_arrData[$strName]['start'] = gettimeofday();
	}
	/**
	 * 计时结束
	 * @param string $strName
	 */
	public static function end($strName)
	{
		self::$_arrData[$strName]['end'] = gettimeofday();
	}
	/**
	 * 计算执行时间，如果没有指定$strName，则返回所有的执行时间数据。
	 * @param string $strName
	 */
	public static function calculate($strName='')
	{
		if (! empty($strName)) {
			return self::_calculateOne($strName);
		} else {
			return self::_calculateAll();
		}
	}
	protected static function _calculateAll()
	{
		if (empty(self::$_arrData)) return array();
		foreach(self::$_arrData as $strName => $arrTime) {
			if (!isset(self::$_arrExecutionTime[$strName])) {
				self::$_arrExecutionTime[$strName] = self::_getExcuteTime($arrTime['start'], $arrTime['end']);
			}
		}
		return self::$_arrExecutionTime;
	}
	
	protected static function _calculateOne($strName)
	{
		if (isset(self::$_arrExecutionTime[$strName])) {
			return self::$_arrExecutionTime[$strName];
		}		
		if (isset(self::$_arrData[$strName])) {
			self::$_arrExecutionTime[$strName] = self::_getExcuteTime(self::$_arrData[$strName]['start'], self::$_arrData[$strName]['end']);
			return self::$_arrExecutionTime[$strName];
		}
		return 0;
	}
	
	protected static function _getExcuteTime($time1,$time2)
	{
        return ($time2['sec'] - $time1['sec'])*1000 + floor(($time2['usec'] - $time1['usec'])/1000);
	}
}