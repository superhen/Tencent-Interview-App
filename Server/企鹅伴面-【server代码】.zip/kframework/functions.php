<?php
/**
 * 框架公用函数
 * @author laiwenhui
 */

/**
 * 使用反斜线转义单引号（'）、双引号（"）、反斜线（\）与 NUL（NULL 字符）。 
 *
 * @param mixed 可以为数组或者字符串
 * @return mixed
 */
function daddslashes($string) {
	if(is_array($string)) {
		$keys = array_keys($string);
		foreach($keys as $key) {
			$val = $string[$key];
			unset($string[$key]);
			$string[addslashes($key)] = daddslashes($val);
		}
	} else {
		$string = addslashes($string);
	}
	return $string;
}
/**
 * 去除转义单引号（'）、双引号（"）、反斜线（\）与 NUL（NULL 字符）的反斜线。 
 *
 * @param mixed 可以为数组或者字符串
 * @return mixed
 */
function dstripslashes($string) {
	if(is_array($string)) {
		foreach($string as $key => $val) {
			$string[$key] = dstripslashes($val);
		}
	} else {
		$string = stripslashes($string);
	}
	return $string;
}
/**
 * 设置全局变量$_G的值
 *
 * @param string $key
 * @param string $value
 * @param string $group
 * @return bool
 */
function setglobal($key , $value, $group = null) {
	global $_G;
	$k = explode('/', $group === null ? $key : $group.'/'.$key);
	switch (count($k)) {
		case 1: $_G[$k[0]] = $value; break;
		case 2: $_G[$k[0]][$k[1]] = $value; break;
		case 3: $_G[$k[0]][$k[1]][$k[2]] = $value; break;
		case 4: $_G[$k[0]][$k[1]][$k[2]][$k[3]] = $value; break;
		case 5: $_G[$k[0]][$k[1]][$k[2]][$k[3]][$k[4]] =$value; break;
	}
	return true;
}
/**
 * 获得全局变量$_G的值
 *
 * @param string $key
 * @param string $value
 * @param string $group
 * @return mixed
 */
function getglobal($key, $group = null) {
	global $_G;
	$k = explode('/', $group === null ? $key : $group.'/'.$key);
	switch (count($k)) {
		case 1: return isset($_G[$k[0]]) ? $_G[$k[0]] : null; break;
		case 2: return isset($_G[$k[0]][$k[1]]) ? $_G[$k[0]][$k[1]] : null; break;
		case 3: return isset($_G[$k[0]][$k[1]][$k[2]]) ? $_G[$k[0]][$k[1]][$k[2]] : null; break;
		case 4: return isset($_G[$k[0]][$k[1]][$k[2]][$k[3]]) ? $_G[$k[0]][$k[1]][$k[2]][$k[3]] : null; break;
		case 5: return isset($_G[$k[0]][$k[1]][$k[2]][$k[3]][$k[4]]) ? $_G[$k[0]][$k[1]][$k[2]][$k[3]][$k[4]] : null; break;
	}
	return null;
}

/**
 * 获得ip
 *
 * @return unknown
 */
function get_client_IP()
{
	if( isset($_SERVER['REMOTE_ADDR']) 
				&& !empty($_SERVER['REMOTE_ADDR']) ){
		$ip = $_SERVER['REMOTE_ADDR'];
	}else if( isset($_SERVER['HTTP_CLIENT_IP']) 
				&& !empty($_SERVER['HTTP_CLIENT_IP']) ){
		$ip = $_SERVER['HTTP_CLIENT_IP'];
	}else if( isset($_SERVER['HTTP_X_FORWARDED_FOR'])
				&& !empty($_SERVER['HTTP_X_FORWARDED_FOR'])){
		$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
	}else{
		$ip = '127.0.0.1';
	}
	
	$pos = strpos($ip, ',');
	if( $pos > 0 )
	{
		$ip = substr($ip, 0, $pos);
	}
	return trim($ip);
}

/**
 * 打印一个数组
 *
 * @param unknown_type $arr
 */
function dump($arr){
	echo '<pre>';
	if (is_array($arr)){
		print_r($arr);
	}else{
		var_dump($arr);
	}
	echo '</pre>';
}
/**
 * debug=2时存储需要打印的日志以便输出
 *
 * @param string $str
 */
function debug_output_str($str){
	//$str = preg_replace('/RETCODE\:(.+?)\|/', '/hjhjhjhj/', $str, 1);
	$str = preg_replace('/RETCODE:([^|]*)/', 'RETCODE:<span style="color:red;font-weight:bold">$1</span>', $str, 1);
	$str = preg_replace('/ERRINFO:([^|]*)/', 'ERRINFO:<span style="color:red;font-weight:bold">$1</span>', $str, 1);
	$str = preg_replace('/TRANSAICINFO:([^|]*)/', 'TRANSAICINFO:<span style="color:red;font-weight:bold">$1</span>', $str, 1);
	global $output_debug_str;
	$output_debug_str .= '<div><p>'.$str.'</p></div>';
}

