<?php
/**
 * 日志打印类
 * @author laiwenhui
 * last modify 2012-07-19 
 */
require_once("tphplib.inc.php");

define("AMS_LOG_L5_MODID","48769");
define("AMS_LOG_L5_CMDID","131072");

class logger
{
	const LOG_LEVEL_NONE    = 0x00;
	const LOG_LEVEL_ERROR   = 0x01;//错误日志
	const LOG_LEVEL_WARNING = 0x02;//警告日志
	const LOG_LEVEL_DEBUG	= 0x04;//调试日志
	const LOG_LEVEL_TRACE   = 0x08;//流水日志
	const LOG_LEVEL_ALL     = 0x0F;

	public static $arrLevels = array(
		self::LOG_LEVEL_ERROR   => 0,
		self::LOG_LEVEL_WARNING => 2,
		self::LOG_LEVEL_DEBUG   => 3,
		self::LOG_LEVEL_TRACE	=> 4,
	);
	public static $strArrLevels = array(
		self::LOG_LEVEL_ERROR   => 'error',
		self::LOG_LEVEL_WARNING => 'waring',
		self::LOG_LEVEL_DEBUG   => 'debug',
		self::LOG_LEVEL_TRACE	=> 'trace',
	);
	
	//日志相关配置
	const CLUBLOG_HEAD_LEN = 13;
	const CLUBLOG_VER = 1;
	const CLUBLOG_CMD = 100;
	const AMS_APPID = 10;
	//项目信息
	protected $appId;
	protected $name;
	protected $dev;
	protected $pdm;
	protected $host;
	protected $port;
	protected $intLevel;
	protected $ratio;

	protected $fp;
	
	private static $instance = null;

	private function __construct($arrLogConfig)
	{
		$this->appId	= intval($arrLogConfig['appId']);
		$this->name		= $arrLogConfig['name'];
		$this->dev		= $arrLogConfig['dev'];
		$this->pdm		= $arrLogConfig['pdm'];
		$this->host		= $arrLogConfig['host'];
		$this->port		= intval($arrLogConfig['port']);
		$this->intLevel	= intval($arrLogConfig['intLevel']);
		$this->ratio	= intval($arrLogConfig['ratio']);
		
		$l5_req = array(
				'flow' => 0,    //无意义，暂时未用
				'modid' => AMS_LOG_L5_MODID,    //modid
				'cmd' => AMS_LOG_L5_CMDID,    //cmdid
				'host_ip' => '',//执行成功时，为路由ip
				'host_port' => 0//执行成功时，为路由port
		);
		$errmsg = '';
		$ret = tphp_l5sys_getroute($l5_req, 0.2, $errmsg);
		if ($ret > 0) {
			$this->host		= $l5_req['host_ip'];
			$this->port		= intval($l5_req['host_port']);
				
			$socket = new tphp_socket($this->host, $this->port);
			$socket->set_module(AMS_LOG_L5_MODID, AMS_LOG_L5_CMDID);
			$socket->connect();
			$socket->update_l5_sys(0);
			$socket->close();
		}
	}
	function __destruct(){
		if ($this->fp){
			fclose($this->fp);
		}
		
	}
	/**
	 * 获得日志对象
	 *
	 * @return unknown
	 */
	public static function getInstance()
	{
		if( self::$instance === null )
		{
			$logConfig = config_global::$log;
			self::$instance = new logger($logConfig);
		}

		return self::$instance;
	}
	public function writeLog($intLevel, $str, $errno = 0, $arrArgs = null, $depth = 0)
	{
		if((!($this->intLevel & $intLevel) || !isset(self::$arrLevels[$intLevel])))
		{
			return;
		}
		if (mt_rand(0, 100) > $this->ratio){
			return ;
		}
		
		$logLevel = self::$arrLevels[$intLevel];

		$trace = debug_backtrace();
		if( $depth >= count($trace) )
		{
			$depth = count($trace) - 1;
		}
		$file = basename($trace[$depth]['file']);
		$function = basename($trace[$depth+1]['function']);
		$line = $trace[$depth]['line'];
		$strArgs = '';
		if( is_array($arrArgs) && count($arrArgs) > 0 )
		{
			foreach( $arrArgs as $key => $value )
			{
				$strArgs .= "{$key}[$value] ";
			}
		}
		//调用信息
		$str = sprintf("FILE:%s|FUNC:%s|LINE:%s|MPSEND:%s|RETCODE:%s|ERRCODE:%s|ERRINFO:%s|TRANSAICINFO:%s|URI:%s",
            $file, $function, $line, '0', $errno, $errno, $str, $strArgs,isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '');
		//项目信息
        $uin   = getglobal('uin')? getglobal('uin') : 0;
        $appid = $this->appId;
		if ($logLevel == 0){
			$actname = $this->name;
	        $pdm = $this->pdm;
	        $dev = $this->dev;
	        $str = sprintf("NAME:%s|PDM:%s|DEV:%s|%s|%s",
	        			$actname, $pdm, $dev, $str, get_client_ip());
	        $str = sprintf("%d|%d|%s", $uin, $appid, $str);
		}else {
			$str = sprintf("uid:%s|actid:%s|%s",
    			$uin, $appid, $str);
		}
		//输出调试信息
		if (DEBUG_MODEL == 1){
			debug_output_str(self::$strArrLevels[$intLevel].' '.$str);
			return ;
		}
		return $this->_write(self::AMS_APPID, $logLevel, $str);
	}
	private function _write($appid, $level, $content, $src = 0)
	{
		$content .= "\n";
		$contentlen = strlen($content) + 1;//var_dump($content);
		$pkglen = self::CLUBLOG_HEAD_LEN + $contentlen;
		$buffer = pack("n6Ca$contentlen", $pkglen, self::CLUBLOG_VER, self::CLUBLOG_CMD, $src, 0, $appid, $level, $content);
		$this->_udpSend($buffer, $pkglen);
		return true;
	}
	private function _udpSend($strSend, $iSendLen, $timeout = 1)
	{
	    if (!$this->fp){
	    	$errno = 0;
		    $errstr = "";
		    $this->fp = fsockopen('udp://' . $this->host, $this->port, $errno, $errstr, $timeout);
		    if (!$this->fp)
		    {
		        return false;
		    }
		    stream_set_timeout($this->fp, $timeout);
	    }
	    $ret = fwrite($this->fp, $strSend, $iSendLen);
	    if ($ret != $iSendLen)
	    {
	        return false;
	    }
	    return true;
	}
	
	/**
	 * 打印错误日志信息
	 *
	 * @param string $str 需要打印的字符串
	 * @param int $errno 错误码
	 * @param array $arrArgs 参数数组
	 * @param int $depth 打印栈深度
	 * @return int
	 */
	public static function error($str, $errno = 0, $arrArgs = null, $depth = 0)
	{
		$log = Logger::getInstance();
		return $log->writeLog(self::LOG_LEVEL_ERROR, $str, $errno, $arrArgs, $depth + 1);
	}
	/**
	 * 打印警告日志，程序异常时打印
	 *
	 * @param string $str 需要打印的字符串
	 * @param int $errno 错误码
	 * @param array $arrArgs 参数数组
	 * @param int $depth 打印栈深度
	 * @return int
	 */
	public static function warning($str, $errno = 0, $arrArgs = null, $depth = 0)
	{
		$log = Logger::getInstance();
		return $log->writeLog(self::LOG_LEVEL_WARNING, $str, $errno, $arrArgs, $depth + 1);
	}
	/**
	 * 打印调试日志，调试用，线上关闭
	 *
	 * @param string $str 需要打印的字符串
	 * @param int $errno 错误码
	 * @param array $arrArgs 参数数组
	 * @param int $depth 打印栈深度
	 * @return int
	 */
	public static function debug($str, $errno = 0, $arrArgs = null, $depth = 0)
	{
		$log = Logger::getInstance();
		return $log->writeLog(self::LOG_LEVEL_DEBUG, $str, $errno, $arrArgs, $depth + 1);
	}
	/**
	 * 打印追踪日志，通常在分支前打印，用于追踪问题
	 *
	 * @param string $str 需要打印的字符串
	 * @param int $errno 错误码
	 * @param array $arrArgs 参数数组
	 * @param int $depth 打印栈深度
	 * @return int
	 */
	public static function trace($str, $errno = 0, $arrArgs = null, $depth = 0)
	{
		$log = Logger::getInstance();
		return $log->writeLog(self::LOG_LEVEL_TRACE, $str, $errno, $arrArgs, $depth + 1);
	}


}




/* vim: set ts=4 sw=4 sts=4 tw=90 noet: */
