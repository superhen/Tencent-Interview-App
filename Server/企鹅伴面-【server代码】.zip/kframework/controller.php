<?php
/**
 * 控制器的基础类
 *
 * @author laiwenhui
 */
class controller
{
    /**
     * 封装请求的对象
     *
     * @var QContext
     */
    protected $_context;
    /**
     * 构造函数
     */
    final  function __construct()
    {
        $this->_context = context::instance();
        $this->_init();
    }
    /**
     * 初始化函数
     *
     */
    protected  function _init(){}
	/**
	 * 模版解析
	 *
	 * @param string $template 模版名称
	 */
	public function getViewPath($tpl=''){
		return VIEW_PATH.$this->_context->getController().'/'.$tpl.'.php';
	}
    /**
     * 检查指定的动作方法是否存在
     *
     * @param string $action_name
     *
     * @return boolean
     */
    public function existsAction($actionName)
    {
    	$methodName = 'action'.ucfirst($actionName);
        return method_exists($this, $methodName);
    }
    
    /**
     * 按路由规则生成url
     *
     * @param string $udi controller/action
     * @param unknown_type $params array('id'=>2)
     * @return url
     */
    public  function url($udi, $params = null){
    	return 'http://'.$this->_context->server('HTTP_HOST').'/'.trim($this->_context->baseDir(),'/').$this->_context->url($udi,$params);
    }
    /**
     * 按路由规则生成url
     *
     * @param string $udi controller/action
     * @param unknown_type $params array('id'=>2)
     * @return url
     */
    public  function redirect($udi, array $params = null, $isPermanently=false){
    	if (strpos($udi,'http') !== false){
    		$url = trim($udi);
    	}else {
    		$url = $this->url($udi,$params);
    	}
    	if ($isPermanently){
    		header("HTTP/1.1 301 Moved Permanently");
    	}
    	header("location:$url");
    }
}
?>