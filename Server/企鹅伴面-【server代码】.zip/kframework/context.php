<?php
/**
 * context 封装了运行时上下文
 *
 * 所谓运行时上下文是指应用程序的运行环境本身。
 * context 主要封装了请求参数和请求状态，以及 URL 解析等功能。
 *
 * context 使用了单例设计模式，因此只能使用 context::instance() 来获得context 对象的唯一实例
 * 
 *
 * @author laiwenhui
 */
class context 
{
    /**
     * 指示 UDI 的默认值
     */
    // 默认控制器
    const UDI_DEFAULT_CONTROLLER = 'default';
    // 默认动作
    const UDI_DEFAULT_ACTION     = 'index';
    static $instance;
    /**
     * 请求包含的控制器名称
     *
     * @var string
     */
    private  $_controller;

    /**
     * 请求包含的动作名
     *
     * @var string
     */
    private $_action;

    /**
     * 附加的参数
     *
     * @var array
     */
    private $_params = array();

    /**
     * 路由对象
     *
     * @var QRouter
     */
    private $_router;

    /**
     * 当前请求 URL
     *
     * @var string
     */
    static private $_request_uri;
	static private $_base_uri;
    static private $_base_dir;

    /**
     * 构造函数
     */
    private function __construct()
    {
        $this->_initSafe();
        $this->_initConfig();
        $this->_initRoute();
    }
    /**
     * 初始化安全过滤，安全检查
     *
     * @return unknown
     */
	private function _initSafe(){
		if(!get_magic_quotes_gpc()) {
			$_GET = daddslashes($_GET);
			$_POST = daddslashes($_POST);
			$_COOKIE = daddslashes($_COOKIE);
			$_FILES = daddslashes($_FILES);
		}
        $_GET = $this->_checkCSRF($_GET);
        $_POST = $this->_checkCSRF($_POST);
        $_COOKIE = $this->_checkCSRF($_COOKIE);
        $_FILES = $this->_checkCSRF($_FILES);
        $_ENV = $this->_checkCSRF($_ENV);
        $_REQUEST = $this->_checkCSRF($_REQUEST);
        $_SERVER = $this->_checkCSRF($_SERVER);
        if(isset($_SESSION)){
            $_SESSION = $this->_checkCSRF($_SESSION);
        }
        if(@$_SERVER['REQUEST_METHOD'] == 'GET' && !empty($_SERVER['REQUEST_URI'])) {
				$temp = strtoupper(urldecode(urldecode($_SERVER['REQUEST_URI'])));
				if(strpos($temp, '<') !== false || strpos($temp, '"') !== false || strpos($temp, 'CONTENT-TRANSFER-ENCODING') !== false) {
					echo "error:异常请求！";
					exit();
				}
		}
		//非法来源一切拒绝
		/*
		if(isset($_SERVER["HTTP_REFERER"]) && !preg_match("/^http:\/\/[\w\.]*\.(qq)\.com/",$_SERVER["HTTP_REFERER"]) ){
			echo "error:非法来源请求！";
		    exit();
		}
		*/
        return true;
	}
    /*
     * 过滤安全漏洞
     */
    private function _checkCSRF($param){
        //过滤
        foreach($param as &$value){
            $value = str_replace("\n","",$value);
            $value = str_replace("%0d%0a","",$value);
        }
        return $param;
    }
	/**
	 * 初始化配置
	 *
	 */
	private function _initConfig(){
		//判断是否开启debug模式，开启后打印错误信息，debug日志
		if (config_global::$debug['model'] > 0){
			error_reporting(E_ALL);
			define('DEBUG_MODEL',intval(config_global::$debug['model']));
		}elseif($this->query('DEBUG') == config_global::$debug['str'] || @$_COOKIE['DEBUG'] == config_global::$debug['str']) {
			error_reporting(E_ALL);
			define('DEBUG_MODEL',intval(config_global::$debug['strmodel']));
		}elseif (DEV_MODE) {
			error_reporting(E_ALL);
			define('DEBUG_MODEL',0);
		}else {
			error_reporting(0);
			define('DEBUG_MODEL',0);
		}
	}
	/**
     * 初始化路由配置
     *
     */
    private function _initRoute()
    {
        $this->_router = new route();
        $result = $this->_router->match($this->pathinfo());
        if ($result === false)
        {
        	$this->_controller = self::UDI_DEFAULT_CONTROLLER;
        	$this->_action = self::UDI_DEFAULT_ACTION;
        }else {
        	$this->_controller = htmlspecialchars($result['controller'], ENT_QUOTES);
         	$this->_action = htmlspecialchars($result['action'], ENT_QUOTES);
         	$this->_params = isset($result['param'])?daddslashes($result['param']):array();
        }
    }
    /**
     * 返回 context 对象的唯一实例
     *
     * @code php
     * $context = context::instance();
     * @endcode
     *
     * @return context 对象的唯一实例
     */
    static function instance()
    {
        if (is_null(self::$instance)){
        	self::$instance = new context();
        }
        return self::$instance;
    }
	/**
     * 根据运行时上下文对象，调用相应的控制器动作方法
     *
     * @param array $args
     *
     * @return mixed
     */
    function dispatching()
    {
    	
    	$className = 'controller_'.$this->_controller;
    	$fileName = APP_PATH.'controller/'.$this->_controller.'.php';
        //构造控制器对象
        //执行before_controller插件
        $config = config_global::$plugin;
        if (!empty($config['before_controller'])){
        	foreach ($config['before_controller'] as $class){
        		$plugin = new $class();
        		$plugin->excute();
        	}
        }
		//controller不存在退出
        if(!file_exists($fileName)){
			echo "controller[".$this->_controller."] not found.";	
			exit();
        }
        $controller = new $className();
        $actionName = $this->_action;
        if ($controller->existsAction($actionName))
        {
        	//执行before_action插件
	        if (!empty($config['before_action'])){
	        	foreach ($config['before_action'] as $class){
	        		$plugin = new $class();
	        		$plugin->excute();
	        	}
	        }
            // 如果指定动作存在，则调用
            $methodName = 'action'.ucfirst($actionName);
            $controller->$methodName();
            //执行after_action插件
	        if (!empty($config['after_action'])){
	        	foreach ($config['after_action'] as $class){
	        		$plugin = new $class();
	        		$plugin->excute();
	        	}
	        }
        }
        else
        {
            // 如果指定动作不存在，跳转到首页
            echo "action[".$this->_action."] not find.";
			exit;
        }
        //执行after_controller插件
        if (!empty($config['after_controller'])){
        	foreach ($config['after_controller'] as $class){
        		$plugin = new $class();
        		$plugin->excute();
        	}
        }
        if (DEBUG_MODEL === 1){
        	global $requestTime;
        	$excuteTime = microtime(true)-$requestTime;
        	logger::debug("响应时间：$excuteTime");
        }
        if (DEBUG_MODEL === 1 && !$this->isAJAX() && !$this->get('ajax')){
        	global $output_debug_str;
        	echo '<div class="out_put_debug">
        			<p style="color:red;">调试日志信息，你可以通过设置debug参数关闭:</p>';
        	echo $output_debug_str;
        	echo '</div>';
        }
    }
    /**
     * 魔法方法，访问请求参数
     *
     * __get() 魔法方法让开发者可以用 $context->parameter 的形式访问请求参数。
     * 如果指定的参数不存在，则返回 null。
     *
     * @code php
     * $title = $context->title;
     * @endcode
     *
     * 查找请求参数的顺行是 $_GET、$_POST 和 QContext 对象附加参数。
     *
     * @param string $parameter 要访问的请求参数
     *
     * @return mixed 参数值
     */
    function __get($parameter)
    {
        return $this->query($parameter);
    }

    /**
     * 魔法方法，设置附加参数
     *
     * 与 __get() 魔法方法不同，__set() 仅仅设置 QContext 对象附加参数。
     * 因此当 $_GET 或 $_POST 中包含同名参数时，用 __set() 设置的参数值
     * 只能使用 QContext::param() 方法来获得。
     *
     * @code php
     * $context->title = $title;
     * echo $context->param('title');
     * @endcode
     *
     * @param string $parameter 要设置值的参数名
     * @param mixed $value 参数值
     */
    function __set($parameter, $value)
    {
        $this->_params[$parameter] = $value;
    }
    /**
     * 获得当前的action
     *
     * @return unknown
     */
    function getAction(){
    	return $this->_action;
    }
    /**
     * 获得当前的controller
     *
     * @return unknown
     */
    function getController(){
    	return $this->_controller;
    }
    /**
     * 魔法方法，访问请求参数
     *
     * QContext::get() 方法让开发者可以用 $context->parameter 的形式访问请求参数。
     * 如果指定的参数不存在，则返回 $default 参数指定的默认值。
     *
     * @code php
     * $title = $context->query('title', 'default title');
     * @endcode
     *
     * 查找请求参数的顺行是 $_GET、$_POST 和 QContext 对象附加参数。
     *
     * @param string $parameter 要访问的请求参数
     * @param mixed $default 参数不存在时要返回的默认值
     *
     * @return mixed 参数值
     */
    function query($parameter, $default = null)
    {
        if (isset($_GET[$parameter]))
            return $_GET[$parameter];
        elseif (isset($_POST[$parameter]))
            return $_POST[$parameter];
        elseif (isset($this->_params[$parameter]))
            return $this->_params[$parameter];
        else
            return $default;
    }

    /**
     * 获得 GET 数据
     *
     * 从 $_GET 中获得指定参数，如果参数不存在则返回 $default 指定的默认值。
     *
     * @code php
     * $title = $context->get('title', 'default title');
     * @endcode
     *
     * 如果 $parameter 参数为 null，则返回整个 $_GET 的内容。
     *
     * @param string $parameter 要查询的参数名
     * @param mixed $default 参数不存在时要返回的默认值
     *
     * @return mixed 参数值
     */
    function get($parameter = null, $default = null)
    {
        if (is_null($parameter))
            return $_GET;
        return isset($_GET[$parameter]) ? $_GET[$parameter] : $default;
    }

    /**
     * 获得 POST 数据
     *
     * 从 $_POST 中获得指定参数，如果参数不存在则返回 $default 指定的默认值。
     *
     * @code php
     * $body = $context->post('body', 'default body');
     * @endcode
     *
     * 如果 $parameter 参数为 null，则返回整个 $_POST 的内容。
     *
     * @param string $parameter 要查询的参数名
     * @param mixed $default 参数不存在时要返回的默认值
     *
     * @return mixed 参数值
     */
    function post($parameter = null, $default = null)
    {
        if (is_null($parameter))
            return $_POST;
        return isset($_POST[$parameter]) ? $_POST[$parameter] : $default;
    }

    /**
     * 获得 Cookie 数据
     *
     * 从 $_COOKIE 中获得指定参数，如果参数不存在则返回 $default 指定的默认值。
     *
     * @code php
     * $auto_login = $context->cookie('auto_login');
     * @endcode
     *
     * 如果 $parameter 参数为 null，则返回整个 $_COOKIE 的内容。
     *
     * @param string $parameter 要查询的参数名
     * @param mixed $default 参数不存在时要返回的默认值
     *
     * @return mixed 参数值
     */
    function cookie($parameter = null, $default = null)
    {
        if (is_null($parameter))
            return $_COOKIE;
        return isset($_COOKIE[$parameter]) ? $_COOKIE[$parameter] : $default;
    }

    /**
     * 从 $_SERVER 查询服务器运行环境数据
     *
     * 如果参数不存在则返回 $default 指定的默认值。
     *
     * @code php
     * $request_time = $context->server('REQUEST_TIME');
     * @endcode
     *
     * 如果 $parameter 参数为 null，则返回整个 $_SERVER 的内容。
     *
     * @param string $parameter 要查询的参数名
     * @param mixed $default 参数不存在时要返回的默认值
     *
     * @return mixed 参数值
     */
    function server($parameter = null, $default = null)
    {
        if (is_null($parameter))
            return $_SERVER;
        return isset($_SERVER[$parameter]) ? $_SERVER[$parameter] : $default;
    }
    /**
     * 获得 QContext 对象的附加参数
     *
     * 如果参数不存在则返回 $default 指定的默认值。
     *
     * @code php
     * $value = $context->param('arg', 'default value');
     * @endcode
     *
     * 如果 $parameter 参数为 null，则返回所有附加参数的内容。
     *
     * @param string $parameter 要查询的参数名
     * @param mixed $default 参数不存在时要返回的默认值
     *
     * @return mixed 参数值
     */
    function param($parameter, $default = null)
    {
        if (is_null($parameter))
            return $this->_params;
        return isset($this->_params[$parameter]) ? $this->_params[$parameter] : $default;
    }

    /**
     * 返回所有上下文参数
     *
     */
    function params()
    {
        return $this->_params;
    }
	/**
     * 确定请求的完整 URL
     *
     * 几个示例：
     *
     * <ul>
     *   <li>请求 http://www.example.com/index.php?controller=posts&action=create</li>
     *   <li>返回 /index.php?controller=posts&action=create</li>
     * </ul>
     * <ul>
     *   <li>请求 http://www.example.com/news/index.php?controller=posts&action=create</li>
     *   <li>返回 /news/index.php?controller=posts&action=create</li>
     * </ul>
     * <ul>
     *   <li>请求 http://www.example.com/index.php/posts/create</li>
     *   <li>返回 /index.php/posts/create</li>
     * </ul>
     * <ul>
     *   <li>请求 http://www.example.com/news/show/id/1</li>
     *   <li>返回 /news/show/id/1</li>
     * </ul>
     *
     * 此方法参考 Zend Framework 实现。
     *
     * @return string 请求的完整 URL
     */
    function requestUri()
    {
        if (self::$_request_uri) return self::$_request_uri;

        if (isset($_SERVER['HTTP_X_REWRITE_URL']))
        {
            $uri = $_SERVER['HTTP_X_REWRITE_URL'];
        }
        elseif (isset($_SERVER['REQUEST_URI']))
        {
            $uri = $_SERVER['REQUEST_URI'];
        }
        elseif (isset($_SERVER['ORIG_PATH_INFO']))
        {
            $uri = $_SERVER['ORIG_PATH_INFO'];
            if (! empty($_SERVER['QUERY_STRING']))
            {
                $uri .= '?' . $_SERVER['QUERY_STRING'];
            }
        }
        else
        {
            $uri = '';
        }

        self::$_request_uri = $uri;
        return $uri;
    }
	/**
     * 返回请求 URL 中的基础路径（不包含脚本名称）
     *
     * 几个示例：
     *
     * <ul>
     *   <li>请求 http://www.example.com/index.php?controller=posts&action=create</li>
     *   <li>返回 /</li>
     * </ul>
     * <ul>
     *   <li>请求 http://www.example.com/news/index.php?controller=posts&action=create</li>
     *   <li>返回 /news/</li>
     * </ul>
     * <ul>
     *   <li>请求 http://www.example.com/index.php/posts/create</li>
     *   <li>返回 /</li>
     * </ul>
     * <ul>
     *   <li>请求 http://www.example.com/news/show/id/1</li>
     *   <li>返回 /</li>
     * </ul>
     *
     * @return string 请求 URL 中的基础路径
     */
    function baseDir()
    {
        if (self::$_base_dir) return self::$_base_dir;

        $base_uri = $this->baseUri();
        if (substr($base_uri, - 1, 1) == '/')
        {
            $base_dir = $base_uri;
        }
        else
        {
            $base_dir = dirname($base_uri);
        }

        self::$_base_dir = rtrim($base_dir, '/\\') . '/';
        return self::$_base_dir;
    }
    /**
     * 返回不包含任何查询参数的 URI（但包含脚本名称）
     *
     * 几个示例：
     *
     * <ul>
     *   <li>请求 http://www.example.com/index.php?controller=posts&action=create</li>
     *   <li>返回 /index.php</li>
     * </ul>
     * <ul>
     *   <li>请求 http://www.example.com/news/index.php?controller=posts&action=create</li>
     *   <li>返回 /news/index.php</li>
     * </ul>
     * <ul>
     *   <li>请求 http://www.example.com/index.php/posts/create</li>
     *   <li>返回 /index.php</li>
     * </ul>
     * <ul>
     *   <li>请求 http://www.example.com/news/show/id/1</li>
     *   <li>返回 /news/show/id/1</li>
     *   <li>假设使用了 URL 重写，并且 index.php 位于根目录</li>
     * </ul>
     *
     * 此方法参考 Zend Framework 实现。
     *
     * @return string 请求 URL 中不包含查询参数的部分
     */
    function baseUri()
    {
        if (self::$_base_uri) return self::$_base_uri;

        $filename = basename($_SERVER['SCRIPT_FILENAME']);

        if (basename($_SERVER['SCRIPT_NAME']) === $filename)
        {
            $url = $_SERVER['SCRIPT_NAME'];
        }
        elseif (basename($_SERVER['PHP_SELF']) === $filename)
        {
            $url = $_SERVER['PHP_SELF'];
        }
        elseif (isset($_SERVER['ORIG_SCRIPT_NAME']) && basename($_SERVER['ORIG_SCRIPT_NAME']) === $filename)
        {
            $url = $_SERVER['ORIG_SCRIPT_NAME']; // 1and1 shared hosting compatibility
        }
        else
        {
            // Backtrack up the script_filename to find the portion matching
            // php_self
            $path = $_SERVER['PHP_SELF'];
            $segs = explode('/', trim($_SERVER['SCRIPT_FILENAME'], '/'));
            $segs = array_reverse($segs);
            $index = 0;
            $last = count($segs);
            $url = '';
            do
            {
                $seg = $segs[$index];
                $url = '/' . $seg . $url;
                ++ $index;
            } while (($last > $index) && (false !== ($pos = strpos($path, $url))) && (0 != $pos));
        }

        // Does the baseUrl have anything in common with the request_uri?
        $request_uri = $this->requestUri();

        if (0 === strpos($request_uri, $url))
        {
            // full $url matches
            self::$_base_uri = $url;
            return self::$_base_uri;
        }

        if (0 === strpos($request_uri, dirname($url)))
        {
            // directory portion of $url matches
            self::$_base_uri = rtrim(dirname($url), '/') . '/';
            return self::$_base_uri;
        }
		if (isset($_SERVER['DOCUMENT_URI']) && 0 === strpos($_SERVER['DOCUMENT_URI'], dirname($url))){
			self::$_base_uri = rtrim(dirname($url), '/') . '/';
            return self::$_base_uri;
		}
    
        if (! strpos($request_uri, basename($url)))
        {
            // no match whatsoever; set it blank
            return '';
        }

        // If using mod_rewrite or ISAPI_Rewrite strip the script filename
        // out of baseUrl. $pos !== 0 makes sure it is not matching a value
        // from PATH_INFO or QUERY_STRING
        if ((strlen($request_uri) >= strlen($url))
            && ((false !== ($pos = strpos($request_uri, $url)))
            && ($pos !== 0)))
        {
            $url = substr($request_uri, 0, $pos + strlen($url));
        }

        self::$_base_uri = rtrim($url, '/') . '/';
        return self::$_base_uri;
    }
    /**
     * 返回 PATHINFO 信息
     *
     * <ul>
     *   <li>请求 http://www.example.com/index.php?controller=posts&action=create</li>
     *   <li>返回 /</li>
     * </ul>
     * <ul>
     *   <li>请求 http://www.example.com/news/index.php?controller=posts&action=create</li>
     *   <li>返回 /</li>
     * </ul>
     * <ul>
     *   <li>请求 http://www.example.com/index.php/posts/create</li>
     *   <li>返回 /</li>
     * </ul>
     * <ul>
     *   <li>请求 http://www.example.com/news/show/id/1</li>
     *   <li>返回 /news/show/id/1</li>
     *   <li>假设使用了 URL 重写，并且 index.php 位于根目录</li>
     * </ul>
     *
     * 此方法参考 Zend Framework 实现。
     *
     * @return string
     */
    function pathinfo()
    {
        if (!empty($_SERVER['PATH_INFO'])) return $_SERVER['PATH_INFO'];

        $base_url = $this->baseUri();

        if (null === ($request_uri = $this->requestUri())) return '';

        // Remove the query string from REQUEST_URI
        if (($pos = strpos($request_uri, '?')))
        {
            $request_uri = substr($request_uri, 0, $pos);
        }

        if ((null !== $base_url) && (false === ($pathinfo = substr($request_uri, strlen($base_url)))))
        {
            // If substr() returns false then PATH_INFO is set to an empty string
            $pathinfo = '';
        }
        elseif (null === $base_url)
        {
            $pathinfo = $request_uri;
        }

        return $pathinfo;
    }
    /**
     * 改变路由用于内部跳转
     *
     */
	function changeRoute($uri, $params){
		$uri = trim($uri);
		if ($uri == '' || $uri=='/' || strpos($uri,'/')===false){
			$this->_controller = 'defalut';
			$this->_action = 'index';
			$this->_params = $params;
		}else {
			$arrUri = explode('/',$uri);
			$this->_controller = empty($arrUri[0])?'defalut':strtolower($arrUri[0]);
			$this->_action = empty($arrUri[1])?'index':strtolower($arrUri[1]);
			$this->_params = $params;
		}
		$this->dispatching();
	}
    /**
     * 返回请求使用的方法
     *
     * @return string
     */
    function requestMethod()
    {
        return $_SERVER['REQUEST_METHOD'];
    }

    /**
     * 是否是 GET 请求
     *
     * @return boolean
     */
    function isGET()
    {
        return $this->requestMethod() == 'GET';
    }

    /**
     * 是否是 POST 请求
     *
     * @return boolean
     */
    function isPOST()
    {
        return $this->requestMethod() == 'POST';
    }

    /**
     * 是否是 PUT 请求
     *
     * @return boolean
     */
    function isPUT()
    {
        return $this->requestMethod() == 'PUT';
    }

    /**
     * 是否是 DELETE 请求
     *
     * @return boolean
     */
    function isDELETE()
    {
        return $this->requestMethod() == 'DELETE';
    }

    /**
     * 是否是 HEAD 请求
     *
     * @return boolean
     */
    function isHEAD()
    {
        return $this->requestMethod() == 'HEAD';
    }
	/**
     * 返回 HTTP 请求头中的指定信息，如果没有指定参数则返回 false
     *
     * @param string $header 要查询的请求头参数
     *
     * @return string 参数值
     */
    function header($header)
    {
        $temp = 'HTTP_' . strtoupper(str_replace('-', '_', $header));
        if (!empty($_SERVER[$temp])){
        	return $_SERVER[$temp];
        } 
        if (function_exists('apache_request_headers'))
        {
            $headers = apache_request_headers();
            if (!empty($headers[$header])) return $headers[$header];
        }
        return false;
    }
    /**
     * 判断 HTTP 请求是否是通过 XMLHttp 发起的
     *
     * @return boolean
     */
    function isAJAX()
    {
        return strtolower($this->header('X_REQUESTED_WITH')) == 'xmlhttprequest';
    }

    /**
     * 判断 HTTP 请求是否是通过 Flash 发起的
     *
     * @return boolean
     */
    function isFlash()
    {
        return strtolower($this->header('USER_AGENT')) == 'shockwave flash';
    }

    /**
     * 返回请求的原始内容
     *
     * @return string
     */
    function requestRawBody()
    {
        $body = file_get_contents('php://input');
        return (strlen(trim($body)) > 0) ? $body : false;
    }

    /**
     * 返回当前请求的参照 URL
     *
     * @return string 当前请求的参照 URL
     */
    function referer()
    {
        return $this->header('REFERER');
    }
    /**
     * 构造 url
     *
     * 用法：
     *
     * @code php
     * url('controller/action', [附加参数数组])
     * @endcode
     *
     *
     * @param string $udi UDI 字符串
     * @param array|string $params 附加参数数组
     * @param string $route_name 路由名
     * @param array $opts 控制如何生成 URL 的选项
     *
     * @return string 生成的 URL 地址
     */
    function url($udi, $params = null)
    {
    	return $this->_router->url($udi, $params);
    }
}

