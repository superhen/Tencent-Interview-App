<?php
/**
 * 环境变量初始化
 * @author laiwenhui 
 *
 */
//应用名称,请用英文
//环境初始化
define('APP_PATH',ROOT_PATH.'app/');
define('LOG_PATH',ROOT_PATH.'log/');
define('DATA_PATH',ROOT_PATH.'data/');
define('LIB_PATH',ROOT_PATH.'lib/');
define('CONFIG_PATH',ROOT_PATH.'config/');
define('WEBROOT_PATH',ROOT_PATH.'htdocs/');

define('CONTROLLER_PATH',APP_PATH.'controller/');
define('LOGIC_PATH',APP_PATH.'logic/');
define('VIEW_PATH',APP_PATH.'view/');
define('PLUGIN_PATH',APP_PATH.'plugin/');

define('FRAME_PATH',dirname(ROOT_PATH).'/kframework/');

//echo get_cfg_var('cfg_file_path');
//是否是开发环境\测试环境
if (get_cfg_var('devmode')){
	define('DEV_MODE', 1);
	//echo "devmode";
}else{
	define('DEV_MODE', 0);
	//echo "no devmode";
}
//是否是测试环境
if (get_cfg_var('testmode')){
	define('TEST_MODE', 1);
	//echo "testmode";
}else{
	define('TEST_MODE', 0);
}
//设置时区
date_default_timezone_set("Asia/Shanghai");
header("Content-Type:text/html;charset=utf-8");
//框架公共函数
require(FRAME_PATH.'functions.php');
//框架错误码
require(CONFIG_PATH.'error.php');
//全局配置
if (DEV_MODE){
	require(CONFIG_PATH.'global_dev.php');
}else {
	require(CONFIG_PATH.'global.php');
}

//计算启动时间点
$requestTime = microtime(true);
//框架包含路径
if (DIRECTORY_SEPARATOR === '\\'){
	ini_set('include_path', LIB_PATH.';'.APP_PATH.';'.FRAME_PATH.';'.ini_get('include_path'));
}else {
	ini_set('include_path', LIB_PATH.':'.APP_PATH.':'.FRAME_PATH.':'.ini_get('include_path'));
}


// 获得手机系统信息
$UA = @$_SERVER['HTTP_USER_AGENT'];
if (isset($_GET['platform']) && ($_GET['platform']==1 || $_GET['platform']=='android')){
	$OS = 'android';
}elseif (isset($_GET['platform']) && ($_GET['platform']==2 || $_GET['platform']=='ios')){
	$OS = 'ios';
}else {
	if(preg_match('/(Android)/i',$UA)){
		$OS = 'android';
	}else if( preg_match('/(iPad).*OS\s([\d_]+)/', $UA) || preg_match('/(iPhone\sOS)\s([\d_]+)/', $UA)){
		$OS = 'ios';
	}else{
		$OS = 'android';
	}
}
define('USER_OS', $OS);

/**
 * 定义自动加载函数
 * @param String
 */
function autoload($className)
{
	$arrDir = explode('_',$className);
    if( count($arrDir)>1 ){
    	$strPath = '';
        foreach( $arrDir as $strDir ){
            $strPath .= $strDir.'/';
        }
        $strPath = substr($strPath,0,-1);
        $strPath .= '.php';
        include_once($strPath);
        return ;
    }
    include_once($className.'.php');
}
spl_autoload_register("autoload");