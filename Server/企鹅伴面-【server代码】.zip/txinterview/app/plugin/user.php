<?php
class plugin_user{
	function excute(){
		
		return true;
	}
}