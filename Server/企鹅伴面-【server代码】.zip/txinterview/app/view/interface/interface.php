<?php
echo str_replace(chr(10), '<br />', <<<END

1. http://pzfok.cc/  导入面试者表格 excel


2. 面试者的登录验证功能  login  参数为手机号和身份证号后四位
http://pzfok.cc/login?telephone=13548411134&idcard=7888
{"cmd":"100","flag":"1","name":"杨雪","school":"西南科技大学","telephone":"13548411134","title":"技术研发类－TRD","process":"一面"}


3. 面试者的签到功能  checkin  参数为手机号和token(默认为123)
http://pzfok.cc/checkin?telephone=13548411134&token=123
{"cmd":"300","name":"杨雪","school":"西南科技大学","title":"技术研发类－TRD","status":"签到"}


4. 查询面试者的所有信息  getinfo  参数为手机号
http://pzfok.cc/getinfo?telephone=13548411134
{"name":"杨雪","telephone":"13548411134","school":"西南科技大学","idcard":"522501193453477888","interviewtime":"2014-09-16 10:00:00","status":"签到","title":"技术研发类－TRD","manager":"fionayan(严明)","manager_telephone":"13344556671","interviewpos":"深圳维也纳酒店407","token":"123","process":"一面","flag":"1","cmd":"900"}


5. 面试者的状态查询  getstatus  参数为手机号

未签到：
http://pzfok.cc/getstatus?telephone=13699425020
{"rank":"-1","flag":"0","name":"朱然","cmd":"200"}

签到：
http://pzfok.cc/getstatus?telephone=13051537675
{"rank":"0","flag":"1","name":"阎铎鑫","cmd":"200"}

完成：
http://pzfok.cc/getstatus?telephone=13541075902
{"rank":"-1","flag":"2","name":"罗宇","cmd":"200"}


6. 面试官的登录功能  interviewerlogin  参数为面试官手机号

面试者队列为空：
http://pzfok.cc/interviewerlogin?manager_telephone=13344556672
{"cmd":"500","flag":"1","waitNum":"0"}

面试队列不为空，同时返回下一个面试者信息：
http://pzfok.cc/interviewerlogin?manager_telephone=13344556670
{"cmd":"500","flag":"1","waitNum":"2","name":"王太平","school":"电子科技大学","title":"技术运营类－TO","status":"签到","telephone":"15828641099"}


7. 面试官的完成按钮功能  complete  参数为面试官手机号和面试者手机号
http://pzfok.cc/complete?manager_telephone=13344556670&telephone=18224423618
{"cmd":"600","waitNum":"2","name":"王太平","school":"电子科技大学","title":"技术运营类－TO","status":"签到","telephone":"15828641099"}


8. 面试官叫号，即给面试者推送面试消息  call  参数为被叫的面试者的手机号
http://pzfok.cc/call?telephone=13051537675
推送给客户端的消息如下：
title: 面试通知
content: {"cmd":"700")

9. 叫所有人(供调试用)  callall  无参数
http://pzfok.cc/callall


10. 获取下一个面试者的信息  getinterviewee
参数manager_telephone为面试官的手机号
可选参数skip为需要跳过的面试者的手机号，即不返回该手机号对应的面试者

缺省：
http://pzfok.cc/getinterviewee?manager_telephone=13344556670
{"name":"王太平","telephone":"15828641099","school":"电子科技大学","idcard":"522501199543453477","interviewtime":"2014-09-16 09:20:00","status":"签到","title":"技术运营类－TO","manager":"ablegao(高向冉)","manager_telephone":"13344556670","interviewpos":"深圳维也纳酒店425","token":"123","cmd":"1000","waitNum":"2"}

需要跳过：
http://pzfok.cc/getinterviewee?manager_telephone=13344556670&skip=15828641099
{"name":"黄琼","telephone":"18011402052","school":"电子科技大学","idcard":"453453453752727827","interviewtime":"2014-09-17 15:00:00","status":"签到","title":"技术研发类－TRD","manager":"ablegao(高向冉)","manager_telephone":"13344556670","interviewpos":"深圳维也纳酒店425","token":"123","cmd":"1000","waitNum":"2"}

签到队列为空 或者 只有一个人但是需要跳过：
http://pzfok.cc/getinterviewee?manager_telephone=13344556672
{"cmd":"1001"}


11. 反馈意见接口  feedback  参数：手机号和反馈意见
http://pzfok.cc/feedback?telephone=13051537675&feedback=这个app真好用
｛'cmd' => '101','flag'=>'1'｝


12. 初始化status(供调试用)  initstatus  可选参数status为 未签到，签到，完成

将所有人的状态均设成 未签到
http://pzfok.cc/initstatus
http://pzfok.cc/initstatus?status=未签到

将所有人的状态均设成 签到
http://pzfok.cc/initstatus?status=签到

将所有人的状态均设成 完成
http://pzfok.cc/initstatus?status=完成


13. 获取所有用户(供调试用)  getall
http://pzfok.cc/getall


END
);
