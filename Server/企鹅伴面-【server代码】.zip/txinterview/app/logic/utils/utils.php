<?php
/**
 * provide some common functions
 * @author cedar
 */

class logic_utils_utils {

    static function isTelephone(&$tele) {

        if (ctype_digit($tele) && (float)$tele > 10000000000 && (float)$tele < 20000000000) {
            return true;
        }
        else {
            return false;
        }
    }

    static function isToken(&$tele) {

        if(preg_match('/[^a-zA-Z_\-0-9]/i', $tele)) {
            return false;
        }
        else {
            return true;
        }
    }

    static function clear($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }
}