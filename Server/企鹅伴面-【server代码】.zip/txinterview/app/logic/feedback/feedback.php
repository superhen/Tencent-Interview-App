<?php

/**
 * feedback logic
 */
class logic_feedback_feedback {
    static function addFeedback($tele, $feedback, $ip) {
        logic_mysql_mysql::initial();

        $dt = date("Y-m-d");

        $sql = "select count(*) as count from feedback where ip = '" . $ip . "' and posttime = '" . $dt . "'";

        //echo $sql;

        $sqlresult = mysql_query($sql);
        $result = mysql_fetch_assoc($sqlresult);

        //echo $result['count'];

        if ($result['count'] > 10) {
            return 0;
        }

        $sql = "insert into feedback (telephone, feedbackInfo, ip, posttime) values('$tele', '$feedback', '$ip', '$dt')";

        //echo $sql;

        $result = mysql_query($sql);

        $rc = mysql_affected_rows();

        return $rc;
    }
}