<?php
/**
 * mysql logic
 * @author cedar
 */

class logic_mysql_mysql {
    private static $instance;
    private static $conn = null;

    static function instance()
    {
        if (is_null(self::$instance)){
            self::$instance = new logic_mysql_mysql();
        }
        return self::$instance;
    }

    static function initial() {
        self::instance();
    }

    private function __construct() {
        $this->_connectMysql();
    }

    function __destruct() {
        mysql_close(self::$conn);
    }

    private function _connectMysql() {
        if ($_SERVER['SERVER_ADDR'] == "127.0.0.1") {
            self::$conn = mysql_connect('127.0.0.1', 'root', '');
        }
        else {
            self::$conn = mysql_connect('10.66.145.15', 'root', 'nj106xz106');
        }
        if (!self::$conn) {
            echo 'connection failed';
            return false;
        }

        mysql_select_db('interview', self::$conn);
        mysql_query("set names utf8;");

        return true;
    }
}