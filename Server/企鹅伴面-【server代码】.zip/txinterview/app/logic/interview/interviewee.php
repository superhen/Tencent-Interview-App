<?php

/**
 * interviewee logic 面试者
 * @author cedar
 */
class logic_interview_interviewee
{

    static function clearPersonalInfo(&$personalInfo)
    {
        // rm keys of numbers
        for ($i = 0; $i < count($personalInfo); $i++) {
            unset($personalInfo[$i]);
        }
    }

    static function getInfo($tele, $idcard = null)
    {
        logic_mysql_mysql::initial();

        $sql = "select * from " . logic_interview_interview::getCurTable() . " where telephone = '" . $tele . "'";

        //echo $sql;
        $result = mysql_query($sql);
        $personalInfo = mysql_fetch_array($result);
        if (empty($personalInfo)) {
            //echo "user not exist";
            return null;
        }

        if (!empty($idcard) && substr($personalInfo["idcard"],strlen($personalInfo["idcard"]) - 4) != $idcard) {
            return null;
        }

        $personalInfo["process"] = logic_interview_interview::getCurStatus();

        switch ($personalInfo["status"]) {
            case "未签到":
                $personalInfo["flag"] = '0';
                break;
            case "签到":
                $personalInfo["flag"] = '1';
                break;
            case "完成":
                $personalInfo["flag"] = '2';
                break;
            default:
                $personalInfo["flag"] = '0';
        }

        self::clearPersonalInfo($personalInfo);

        return $personalInfo;
    }

    static function getStatus($tele)
    {
        logic_mysql_mysql::initial();

        $personalInfo = self::getInfo($tele);
        if (!$personalInfo) {
            exit(1);
        }

        $sql = "select COUNT(*) as count from " . logic_interview_interview::getCurTable() . " where status = '签到' and manager = '" . $personalInfo['manager'] . "' and interviewtime < '" . $personalInfo['interviewtime'] . "'";
        //echo $sql;
        $result = mysql_query($sql);
        $arr = mysql_fetch_assoc($result);

        $resultArr = array('rank' => '-1', 'flag' => $personalInfo['flag']);
        $resultArr["name"] = $personalInfo['name'];

        if ($personalInfo['status'] == '签到') {
            $resultArr["rank"] = $arr["count"];
        }
        return $resultArr;
    }

    static function checkin($tele, $token)
    {
        logic_mysql_mysql::initial();

        $personalInfo = logic_interview_interviewee::getInfo($tele);

        if ($personalInfo['status'] == '未签到') {
            $result = mysql_query("select * from " . logic_interview_interview::getCurTable() . " where telephone = '" . $tele . "'and token='" . $token . "'");

            $personalInfo = mysql_fetch_array($result);

            if (!empty($personalInfo)) {

                mysql_query("update " . logic_interview_interview::getCurTable() . " set status = '签到' where telephone='" . $tele . "'");
                mysql_query("COMMIT");

                return $personalInfo;
            }
            else {
                return null;
            }
        }
        else if ($personalInfo['status'] == '签到'){
            return array('msg' => '签到失败，您已经签到');
        }
        else {
            return array('msg' => '签到失败，您已经完成面试');
        }
    }

    static function initStatus($status) {
        logic_mysql_mysql::initial();

        mysql_query("update " . logic_interview_interview::getCurTable() . " set status = '" . $status . "'");

        return mysql_affected_rows();
    }

    static function getAll() {
        logic_mysql_mysql::initial();

        $sql = mysql_query("select * from " . logic_interview_interview::getCurTable() . " order by manager_telephone");
        $userinfo = array();

        while ($row_user = mysql_fetch_assoc($sql)) {
            $userinfo[] = $row_user;
        }

        return $userinfo;
    }
}