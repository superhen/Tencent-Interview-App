<?php

/**
 * interviewer logic
 * @author cedar
 */
class logic_interview_interviewer
{

    static function getManagerInfo($managerTele)
    {
        logic_mysql_mysql::initial();

        $sql = "select * from " . logic_interview_interview::getCurTable() . " where manager_telephone = '" . $managerTele . "'";
        //echo $sql;
        $result = mysql_query($sql);
        $personalInfo = mysql_fetch_array($result);
        if (empty($personalInfo)) {
            //echo "manager not exist";
            return null;
        }

        logic_interview_interviewee::clearPersonalInfo($personalInfo);

        return $personalInfo;
    }

    static function getNextInterviewee($managerTele, $num = 1)
    {
        logic_mysql_mysql::initial();

        if (!self::getManagerInfo($managerTele)) {
            return null;
        }

        $sql = "select * from " . logic_interview_interview::getCurTable() . " where manager_telephone = '" . $managerTele . "' and status = '签到' order by interviewtime limit $num";
        //echo $sql;
        $sqlresult = mysql_query($sql);
        $personalInfo = mysql_fetch_array($sqlresult);
        if (empty($personalInfo)) {
            //echo "no check in interviewer";
            return null;
        }

        logic_interview_interviewee::clearPersonalInfo($personalInfo);

        if ($num == 1) {
            return $personalInfo;
        } else {
            $result = Array($personalInfo);
            while ($personalInfo = mysql_fetch_array($sqlresult)) {
                logic_interview_interviewee::clearPersonalInfo($personalInfo);
                array_push($result, $personalInfo);
            }
            return $result;
        }
    }

    static function getWaitNum($managerTele)
    {
        logic_mysql_mysql::initial();

        if (!self::getManagerInfo($managerTele)) {
            return 0;
        }

        $sql = "select COUNT(*) as count from " . logic_interview_interview::getCurTable() . " where manager_telephone = '" . $managerTele . "' and status = '签到'";
        //echo $sql;
        $sqlresult = mysql_query($sql);
        $arr = mysql_fetch_assoc($sqlresult);

        return $arr["count"];
    }

    static function complete($managerTele, $tele)
    {
        logic_mysql_mysql::initial();

        $sql = "update " . logic_interview_interview::getCurTable() . "  set status='完成' where manager_telephone='" . $managerTele . "' and status ='签到' and telephone='" . $tele . "'";

        $result = mysql_query($sql);
        mysql_query("COMMIT");
    }

}