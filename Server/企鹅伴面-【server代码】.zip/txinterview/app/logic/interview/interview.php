<?php

/**
 * interview logic
 * @author cedar
 */
class logic_interview_interview
{

    // get current table, can be interviewer1, interviewer2, interviewer3
    static function getCurTable()
    {
        logic_mysql_mysql::initial();

        $result = "interview1";
        $sqlresult = mysql_query("select COUNT(*) as count from interview3");
        if ($sqlresult && mysql_fetch_assoc($sqlresult)["count"] > 0) {
            $result = "interview3";
        } else {
            $sqlresult = mysql_query("select COUNT(*) as count from interview2");
            if ($sqlresult && mysql_fetch_assoc($sqlresult)["count"] > 0) {
                $result = "interview2";
            } else {
                $sqlresult = mysql_query("select COUNT(*) as count from interview1");
                if ($sqlresult && mysql_fetch_assoc($sqlresult)["count"] > 0) {
                    $result = "interview1";
                } else {
                    echo "empty table";
                }
            }
        }
        return $result;
    }

    // get current status, can be 一面，二面，三面
    static function getCurStatus()
    {
        $statusName = Array('interview1' => '一面', 'interview2' => '二面', 'interview3' => '三面');
        return $statusName[self::getCurTable()];
    }

}