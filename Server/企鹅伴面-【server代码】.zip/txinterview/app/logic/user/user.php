<?php
/**
 * user logic
 * @author cedar
 */

class logic_user_user {

    public function test($uin) {
        if ($uin % 2 == 0) {
            //logger::debug("ż��");
        }
        else {
            //logger::error("����");
        }

        return $uin;
    }
}