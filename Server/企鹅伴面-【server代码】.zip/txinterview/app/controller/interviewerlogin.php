<?php

class controller_interviewerlogin extends controller
{
    /**
     * @author: pzf, for interviewer login, return checkin status and next interviewee
     *
     */
    public function actionIndex()
    {
        $tele = $_GET['manager_telephone'];

        if (empty($tele) || !logic_utils_utils::isTelephone($tele)) {
            //echo 'no manager_telephone';
            echo json_encode(array('cmd' => '500', 'flag' => '0'), JSON_UNESCAPED_UNICODE);
            exit(1);
        }

        $personalInfo = logic_interview_interviewer::getManagerInfo($tele);

        if (!$personalInfo) {

            $resultArr = array('cmd' => '500', 'flag' => '0');
            echo json_encode($resultArr, JSON_UNESCAPED_UNICODE);
        } else {
            $num = logic_interview_interviewer::getWaitNum($tele);
            if ($num == 0) {
                $resultArr = array('cmd' => '500',
                    'flag' => '1',
                    'waitNum' => '0');
                echo json_encode($resultArr, JSON_UNESCAPED_UNICODE);
            } else {
                $personalInfo = logic_interview_interviewer::getNextInterviewee($tele);

                $resultArr = array('cmd' => '500',
                    'flag' => '1',
                    'waitNum' => $num,
                    'name' => $personalInfo['name'],
                    'school' => $personalInfo['school'],
                    'title' => $personalInfo['title'],
                    'status' => $personalInfo['status'],
                    'telephone' => $personalInfo['telephone']);

                echo json_encode($resultArr, JSON_UNESCAPED_UNICODE);
            }

        }

    }
}