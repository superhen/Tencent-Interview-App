<?php
class controller_getinfo extends controller
{
    /**
     * @author: cedar, return personal info
     *
     */
    public function actionIndex()
    {
        if (!isset($_GET['telephone']) || !logic_utils_utils::isTelephone($_GET['telephone'])) {
            echo 'no telephone';
            exit(1);
        }

        $tele = $_GET['telephone'];
        $personalInfo = logic_interview_interviewee::getInfo($tele);
        if (!$personalInfo) {
            exit(1);
        }

        $personalInfo["cmd"] = "900";

        echo json_encode($personalInfo, JSON_UNESCAPED_UNICODE);
    }
}