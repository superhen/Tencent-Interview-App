<?php
class controller_login extends controller
{
    /**
     * @author: pzf, return login info
     *
     */
    public function actionIndex()
    {
        $tele=$_GET['telephone'];
		$idcard=$_GET['idcard'];

		if (empty($tele) || !logic_utils_utils::isTelephone($tele)) {
			//echo 'no telephone';
			echo json_encode(array('cmd' => '100','flag'=>'0'),JSON_UNESCAPED_UNICODE);
			exit(1);
		}

		if (empty($idcard) || !logic_utils_utils::isToken($idcard)) {
			//echo 'no idcard';
			echo json_encode(array('cmd' => '100','flag'=>'0'),JSON_UNESCAPED_UNICODE);
			exit(1);
		}

		$personalInfo = logic_interview_interviewee::getInfo($tele, $idcard);

		if ($personalInfo['telephone'] == $tele ) {
			$resultInfo = array('cmd' => '100',
				'flag'=>'1',
				'name' => $personalInfo['name'],
				'school' => $personalInfo['school'],
				'telephone' => $personalInfo['telephone'],
				'title' => $personalInfo['title'],
				'interviewpos' => $personalInfo['interviewpos'],
				'status' => $personalInfo['status'],
				'process'=> logic_interview_interview::getCurStatus());

			echo json_encode($resultInfo,JSON_UNESCAPED_UNICODE);
		}
		else {
			echo json_encode(array('cmd' => '100','flag'=>'0'),JSON_UNESCAPED_UNICODE);
		}
		

 
    }
}