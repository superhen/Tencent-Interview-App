<?php
require (LIB_PATH."/XingeApp.php");

class controller_initstatus extends controller
{
    /**
     * @author: cedar, init all status to 签到
     *
     */
    public function actionIndex() {
        $status = $_GET['status'];
        if (empty($status)) {
            $status = "未签到";
        }

        echo "changed: " . logic_interview_interviewee::initStatus($status);
    }
}
