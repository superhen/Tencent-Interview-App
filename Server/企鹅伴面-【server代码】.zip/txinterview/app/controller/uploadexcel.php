<?php

//header("Content-Type:text/html; charset=utf-8");

//define('PHPEXCEL_ROOT', LIB_PATH . '/phpexcel/Classes/');

require_once(LIB_PATH . '/phpexcel/Classes/PHPExcel.php');
require_once(LIB_PATH . '/phpexcel/Classes/PHPExcel/IOFactory.php');
require_once(LIB_PATH . '/phpexcel/Classes/PHPExcel/Reader/Excel5.php');

/*
require_once 'phpexcel/Classes/PHPExcel.php';
require_once 'phpexcel/Classes/PHPExcel/IOFactory.php';
require_once 'phpexcel/Classes/PHPExcel/Reader/Excel5.php';
*/

class controller_uploadexcel extends controller
{
    public function actionIndex()
    {
        if ($_FILES["file"]["error"] > 0) {
            echo "Error: " . $_FILES["file"]["error"] . "<br />";
        } else {
            echo "Upload: " . $_FILES["file"]["name"] . "<br />";
            echo "Type: " . $_FILES["file"]["type"] . "<br />";
            echo "Size: " . ($_FILES["file"]["size"] / 1024) . " Kb<br />";
            echo "Stored in: " . $_FILES["file"]["tmp_name"];
        }

        echo '<br>';
        //iconv("UTF-8", "GB2312", $_FILES["file"]["tmp_name"]);

        $objReader = PHPExcel_IOFactory::createReader('Excel5');//use excel2007 for 2007 format
        $objPHPExcel = $objReader->load($_FILES["file"]["tmp_name"]); //$filename可以是上传的文件，或者是指定的文件
        $sheet = $objPHPExcel->getSheet(0);
        $highestRow = $sheet->getHighestRow(); // 取得总行数
        $highestColumn = $sheet->getHighestColumn();// 取得总列数

        echo 'the max row: ' . $highestRow . '<br>';
        echo 'the max column: ' . $highestColumn . '<br>';

        logic_mysql_mysql::initial();

        mysql_query("drop table " . logic_interview_interview::getCurTable());

        $sql = "CREATE TABLE if NOT EXISTS " . logic_interview_interview::getCurTable() . "
        (
          name varchar(20),
          telephone varchar(20),
          PRIMARY KEY (telephone),
          school varchar(20),
          idcard varchar(20),
          interviewtime timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
          status varchar(20),
          title varchar(20),
          manager varchar(20),
          manager_telephone varchar(20),
          interviewpos varchar(20),
          token varchar(20)
        )ENGINE=InnoDB DEFAULT CHARSET=utf8";

        if (!mysql_query($sql)) {
            exit('creat table failed<br>');
        }

        $a = array();
        for ($j = 2; $j <= $highestRow; $j++) {
            //$sql = "INSERT INTO Interviewer VALUES(";
            $k = 0;
            for ($i = 'A'; $i <= $highestColumn; $i++) {
                $a[$k] = $objPHPExcel->getActiveSheet()->getCell($i . $j)->getValue();
                // $sql .= $a[$k];
                // $sql .= ',';
                //echo $a[$k];
                //echo " ";
                $k++;
            }
            // echo '<br>';
            //$sql[strlen($sql)] = ")";
            //echo $a[0];
            var_dump($a);
            $sql = "INSERT INTO " . logic_interview_interview::getCurTable() . " VALUES('" . $a[0] . "', '" . $a[1] . "', '" . $a[2] . "', '" . $a[3] . "', '" . $a[4] . "','" . $a[5] . "','" . $a[6] . "','" . $a[7] . "','" . $a[8] . "','" . $a[9] . "','" . $a[10] . "')";/*tel_num,school,interview_time,interview_num,interview_post,interviewer_name)*/
            if (!mysql_query($sql)) {
                exit("insert failed");
            }
        }
    }
}

?>