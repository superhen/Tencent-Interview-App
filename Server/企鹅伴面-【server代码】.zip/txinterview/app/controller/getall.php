<?php
require (LIB_PATH."/XingeApp.php");

class controller_getall extends controller
{
    /**
     * @author: cedar, get all users
     *
     */
    public function actionIndex() {
        $userinfo = logic_interview_interviewee::getAll();

        foreach($userinfo as $d){
            foreach($d as $v){
                echo $v."&nbsp;";
            }
            echo "<br/>";
        }
    }
}
