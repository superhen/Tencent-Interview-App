<?php
class controller_getstatus extends controller
{
    /**
     * @author: cedar, return personal status
     *
     */
    public function actionIndex()
    {
        if (!isset($_GET['telephone']) || !logic_utils_utils::isTelephone($_GET['telephone'])) {
            echo 'no telephone';
            exit(1);
        }

        $personalStatus = logic_interview_interviewee::getStatus($_GET['telephone']);

        $personalStatus['cmd'] = '200';

        echo json_encode($personalStatus, JSON_UNESCAPED_UNICODE);
    }
}