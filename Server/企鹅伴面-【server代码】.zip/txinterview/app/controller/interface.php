<?php
class controller_interface extends controller
{
    /**
     * /interface  show interfaces
     *
     */
    public function actionIndex(){
        require $this->getViewPath('interface');

        //用return结束，禁止用exit，因为后面还有其他逻辑（如时间统计、插件等）
        return ;
    }
}
