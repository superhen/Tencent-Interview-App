<?php
class controller_feedback extends controller
{
    /**
     * @author: pzf, add feedback
     *
     */
    public function actionIndex()
    {
		$tele=$_GET['telephone'];
		$feedback=$_GET['feedback'];

		if (empty($tele) || !logic_utils_utils::isTelephone($tele)) {
			echo 'no telephone';
			exit(1);
		}
		if (empty($feedback)) {
			echo 'no feedback';
			exit(1);
		}

		$feedback = logic_utils_utils::clear($feedback);

		if (logic_feedback_feedback::addFeedback($tele, $feedback, $_SERVER['REMOTE_ADDR'])) {
			$resultInfo = array('cmd' => '101','flag'=>'1');
		}else {
			$resultInfo = array('cmd' => '101','flag'=>'0');
		}
		echo json_encode($resultInfo,JSON_UNESCAPED_UNICODE);
	}
}