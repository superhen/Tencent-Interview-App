<?php

class controller_checkin extends controller
{
    /**
     * @author: pzf, for interviewee checkin
     *
     */
    public function actionIndex()
    {


        $tele = $_GET['telephone'];
        $token = $_GET['token'];
        if (empty($_GET['telephone']) || !logic_utils_utils::isTelephone($_GET['telephone'])) {
            echo 'no telephone';
            exit(1);
        }
        if (empty($_GET['token']) || !logic_utils_utils::isToken($_GET['token'])) {
            echo 'no token';
            exit(1);
        }

        $personalInfo = logic_interview_interviewee::checkin($tele, $token);
        if (isset($personalInfo['msg'])) {
            $arr = array('cmd' => '301', 'msg' => $personalInfo['msg']);
        }
        else if (!empty($personalInfo)) {
            $arr = array('cmd' => '300',
                'name' => $personalInfo['name'],
                'school' => $personalInfo['school'],
                'title' => $personalInfo['title'],
                'status' => $personalInfo['status']);
        }
        else {
            $arr = array('cmd' => '301', 'msg' => '签到失败');
        }


        echo json_encode($arr, JSON_UNESCAPED_UNICODE);
    }
}