<?php
require (LIB_PATH."/XingeApp.php");

class controller_callall extends controller
{
    /**
     * @author: cedar, push to all users
     *
     */
    public function actionIndex() {
        $pushResult = XingeApp::PushAllAndroid(2100131237, "d843c635193978a6ca1c22477fa2fd6f", "测试", "推送给所有人 by cedar");

        var_dump($pushResult);
    }
}
