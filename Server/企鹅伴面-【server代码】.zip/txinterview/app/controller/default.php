<?php
class controller_default extends controller
{
    /**
     * demo页面通过domain/default/index或者domain/或者或者domain/default访问
     *
     */
    public function actionIndex(){
        //假设uin为从登录态获取的数据
        //$uin = 12165099;
        //无需包含，直接应用，按规范命名类文件，系统自动加载
        //$userLogic = new logic_user_user();
        //时间统计，可以通过timer::calculate('getClubStatus')获得统计的结果，timer::calculate()则获得全部
        //timer::start('getClubStatus');
        //$clubStatus = $userLogic->test($uin);
        //timer::end('getClubStatus');
        //echo $clubStatus;

        require $this->getViewPath('index');

        //用return结束，禁止用exit，因为后面还有其他逻辑（如时间统计、插件等）
        return ;
    }
    /**
     * 测试页面，通过domain/default/test访问
     *
     */
    public function actionTest(){
        echo '测试action';
        return ;
    }
}
