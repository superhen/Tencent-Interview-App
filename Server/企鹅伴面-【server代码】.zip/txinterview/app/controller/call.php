<?php
require (LIB_PATH."/XingeApp.php");

class controller_call extends controller
{
    /**
     * @author: cedar, call by telephone, push by Xinge
     *
     */
    public function actionIndex() {
        if (!isset($_GET['telephone']) || !logic_utils_utils::isTelephone($_GET['telephone']))
        {
            echo 'no telephone';
            exit(1);
        }

        $tele = $_GET['telephone'];

        echo "push to $tele";

        $personalInfo = logic_interview_interviewee::getInfo($tele);
        //$msg = json_encode(array('cmd' => '700'), JSON_UNESCAPED_UNICODE);
        $msg = $personalInfo["name"] . "您好，您的面试地点是：" . $personalInfo["interviewpos"] . "，请准时参加。";

        $push = new XingeApp(2100131237, 'd843c635193978a6ca1c22477fa2fd6f');
        $mess = new Message();
        $mess->setType(Message::TYPE_NOTIFICATION);
        $mess->setTitle("面试通知");
        $mess->setContent($msg);
        //$mess->setExpireTime(86400);

        //$mess->setStyle(new Style(0,1,1,0,0));

        $action = new ClickAction();
        $action->setActionType(ClickAction::TYPE_ACTIVITY);
        $action->setActivity("com.tencent.miniten.ui.MsgNotifyActivity");
        //$action->setComfirmOnUrl(0);
        $mess->setAction($action);

        //$push = new XingeApp(2100131237, 'd843c635193978a6ca1c22477fa2fd6f');
        //$mess = new Message();
        //完善Message消息
        $ret = $push->PushSingleAccount(0, $tele, $mess);

        //$ret = $push->PushAllDevices(0, $mess);


        //$pushResult = $push->PushSingleAccount(0, $tele, $mess);
        //$pushResult = XingeApp::PushAccountAndroid(2100131237, "d843c635193978a6ca1c22477fa2fd6f", "面试通知", $msg, $tele);

        var_dump($ret);
    }
}
