<?php
class controller_complete extends controller
{
    /**
     * @author: pzf, complete current interviewee and return next interviewee info
     *
     */
    public function actionIndex()
    {
        $manager_telephone=$_GET['manager_telephone'];
		$tele=$_GET['telephone'];

		if (empty($tele) || !logic_utils_utils::isTelephone($tele)) {
			echo 'no telephone';
			exit(1);
		}
		if(empty($manager_telephone) || !logic_utils_utils::isTelephone($manager_telephone)){
			echo'no manager telephone';
			exit(1);
		}

		logic_interview_interviewer::complete($manager_telephone, $tele);

		$count = logic_interview_interviewer::getWaitNum($manager_telephone);

		if($count == '0'){
			echo 'no check in interviewer ';
		}
		else{

			$arr1=logic_interview_interviewer::getNextInterviewee($manager_telephone);
			$resultArr = array('cmd' => '600',
			'waitNum' => $count,
			'name' => $arr1['name'],
			'school' => $arr1['school'],
			'title' => $arr1['title'],
			'status' => $arr1['status'],
			'telephone' => $arr1['telephone']);

			echo json_encode($resultArr, JSON_UNESCAPED_UNICODE);
		}
    }
}