<?php
class controller_getinterviewee extends controller
{
    /**
     * @author: cedar, get next interviewer, can skip
     *
     */
    public function actionIndex()
    {
        if (!isset($_GET['manager_telephone']) || !logic_utils_utils::isTelephone($_GET['manager_telephone']) ) {
            echo 'no manager_telephone';
            exit(1);
        }

        $tele = $_GET['manager_telephone'];
        $personalInfo = logic_interview_interviewer::getNextInterviewee($tele);
        if (!$personalInfo) {
            echo json_encode(array('cmd' => '1001'), JSON_UNESCAPED_UNICODE);
            exit(1);
        }

        if (isset($_GET['skip']) && $personalInfo["telephone"] == $_GET['skip']) {
            $persons = logic_interview_interviewer::getNextInterviewee($tele, 2);
            if (count($persons) <= 1) {
                echo json_encode(array('cmd' => '1001'), JSON_UNESCAPED_UNICODE);
                exit(1);
            }
            $personalInfo = $persons[1];
        }

        $personalInfo['cmd'] = '1000';
        $personalInfo['waitNum'] = logic_interview_interviewer::getWaitNum($tele);
        echo json_encode($personalInfo, JSON_UNESCAPED_UNICODE);
    }
}