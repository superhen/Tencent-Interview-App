<?php
header('Content-type:text/html;Charset=UTF-8');
error_reporting(E_ALL);//如果非debug模式后面会关闭
define('ROOT_PATH',dirname(dirname(__file__)).'/');
require(ROOT_PATH.'/app/run.php');
$context = context::instance();
$context->dispatching();
?>