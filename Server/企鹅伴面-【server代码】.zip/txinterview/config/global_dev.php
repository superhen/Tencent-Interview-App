<?php
class config_global{
	static public $debug = null;
	static public $plugin = null; 
	static public $log = null; 
	static public $cmem = null; 
	static public $actCmem = null; 
	static public $numpkg = null; 
}
// --------------------------  调试配置  --------------------------- //
//是否是debug模式,debug模式会开启错误信息，禁用缓存
//0为关闭调试模式
//1表示开启调试模式，打印PHP错误，打印调试信息、日志，响应时间等信息
config_global::$debug['model'] = 0;
//该参数用来配置通过query参数DEBUG打开debug时，debug基本。含义同上
config_global::$debug['strmodel'] = 1;
//该参数用来配置通过query参数DEBUG打开debug时的字符串 
config_global::$debug['str'] = 'test';


// --------------------------  插件配置  --------------------------- //
config_global::$plugin['before_controller'] = array('plugin_user');
config_global::$plugin['after_controller'] = array();
config_global::$plugin['before_action'] = array();
config_global::$plugin['after_action'] = array();


// --------------------------  日志配置  --------------------------- //
/*
 *日志打印级别
 *0x00:不打印日志
 *0x01：打印ERROR
 *0x02：打印WARNING日志
 *0x04：打印DEBUG日志
 *0x08：打印TRACE日志
 *0x0F：打印所有日志
*/
//日志打印appid
?>